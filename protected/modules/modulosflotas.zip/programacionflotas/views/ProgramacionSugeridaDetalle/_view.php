<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdProgramacionSugeridaDetalle')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->IdProgramacionSugeridaDetalle),array('view','id'=>$data->IdProgramacionSugeridaDetalle)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdProgramacionSugerida')); ?>:</b>
	<?php echo CHtml::encode($data->IdProgramacionSugerida); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NumeroMensajero')); ?>:</b>
	<?php echo CHtml::encode($data->NumeroMensajero); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraCero')); ?>:</b>
	<?php echo CHtml::encode($data->HoraCero); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraUno')); ?>:</b>
	<?php echo CHtml::encode($data->HoraUno); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraDos')); ?>:</b>
	<?php echo CHtml::encode($data->HoraDos); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraTres')); ?>:</b>
	<?php echo CHtml::encode($data->HoraTres); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraCuatro')); ?>:</b>
	<?php echo CHtml::encode($data->HoraCuatro); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraCinco')); ?>:</b>
	<?php echo CHtml::encode($data->HoraCinco); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraSeis')); ?>:</b>
	<?php echo CHtml::encode($data->HoraSeis); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraSiete')); ?>:</b>
	<?php echo CHtml::encode($data->HoraSiete); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraOcho')); ?>:</b>
	<?php echo CHtml::encode($data->HoraOcho); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraNueve')); ?>:</b>
	<?php echo CHtml::encode($data->HoraNueve); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraDiez')); ?>:</b>
	<?php echo CHtml::encode($data->HoraDiez); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraOnce')); ?>:</b>
	<?php echo CHtml::encode($data->HoraOnce); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraDoce')); ?>:</b>
	<?php echo CHtml::encode($data->HoraDoce); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraTrece')); ?>:</b>
	<?php echo CHtml::encode($data->HoraTrece); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraCatorce')); ?>:</b>
	<?php echo CHtml::encode($data->HoraCatorce); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraQuince')); ?>:</b>
	<?php echo CHtml::encode($data->HoraQuince); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraDieciSeis')); ?>:</b>
	<?php echo CHtml::encode($data->HoraDieciSeis); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraDieciSiete')); ?>:</b>
	<?php echo CHtml::encode($data->HoraDieciSiete); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraDieciOcho')); ?>:</b>
	<?php echo CHtml::encode($data->HoraDieciOcho); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraDieciNueve')); ?>:</b>
	<?php echo CHtml::encode($data->HoraDieciNueve); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraVeinte')); ?>:</b>
	<?php echo CHtml::encode($data->HoraVeinte); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraVeintiUna')); ?>:</b>
	<?php echo CHtml::encode($data->HoraVeintiUna); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraVeintiDos')); ?>:</b>
	<?php echo CHtml::encode($data->HoraVeintiDos); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraVeintiTres')); ?>:</b>
	<?php echo CHtml::encode($data->HoraVeintiTres); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TotalHorasProgramadas')); ?>:</b>
	<?php echo CHtml::encode($data->TotalHorasProgramadas); ?>
	<br />

	*/ ?>

</div>