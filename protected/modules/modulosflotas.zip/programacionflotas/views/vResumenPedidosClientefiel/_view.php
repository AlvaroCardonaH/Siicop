<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdReportePedidosxPdv')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->IdReportePedidosxPdv),array('view','id'=>$data->IdReportePedidosxPdv)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdSede')); ?>:</b>
	<?php echo CHtml::encode($data->IdSede); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NombreSede')); ?>:</b>
	<?php echo CHtml::encode($data->NombreSede); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdFlota')); ?>:</b>
	<?php echo CHtml::encode($data->IdFlota); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NombreFlota')); ?>:</b>
	<?php echo CHtml::encode($data->NombreFlota); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdClasificacionDia')); ?>:</b>
	<?php echo CHtml::encode($data->IdClasificacionDia); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NombreClasificacionDia')); ?>:</b>
	<?php echo CHtml::encode($data->NombreClasificacionDia); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('NumeroPosicion')); ?>:</b>
	<?php echo CHtml::encode($data->NumeroPosicion); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdHorario')); ?>:</b>
	<?php echo CHtml::encode($data->IdHorario); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraInicio')); ?>:</b>
	<?php echo CHtml::encode($data->HoraInicio); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraFinal')); ?>:</b>
	<?php echo CHtml::encode($data->HoraFinal); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NumeroServicios')); ?>:</b>
	<?php echo CHtml::encode($data->NumeroServicios); ?>
	<br />

	*/ ?>

</div>