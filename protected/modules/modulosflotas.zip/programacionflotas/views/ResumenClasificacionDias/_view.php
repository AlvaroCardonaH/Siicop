<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdReportePedidosxPdv')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->IdReportePedidosxPdv),array('view','id'=>$data->IdReportePedidosxPdv)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdClasificacionDia')); ?>:</b>
	<?php echo CHtml::encode($data->IdClasificacionDia); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NumeroPosicion')); ?>:</b>
	<?php echo CHtml::encode($data->NumeroPosicion); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdHorario')); ?>:</b>
	<?php echo CHtml::encode($data->IdHorario); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraInicio')); ?>:</b>
	<?php echo CHtml::encode($data->HoraInicio); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('HoraFinal')); ?>:</b>
	<?php echo CHtml::encode($data->HoraFinal); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Lunes_Servicios')); ?>:</b>
	<?php echo CHtml::encode($data->Lunes_Servicios); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('Numero_Mensajeros_Lunes')); ?>:</b>
	<?php echo CHtml::encode($data->Numero_Mensajeros_Lunes); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Martes_Servicios')); ?>:</b>
	<?php echo CHtml::encode($data->Martes_Servicios); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Numero_Mensajeros_Martes')); ?>:</b>
	<?php echo CHtml::encode($data->Numero_Mensajeros_Martes); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Miercoles_Servicios')); ?>:</b>
	<?php echo CHtml::encode($data->Miercoles_Servicios); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Numero_Mensajeros_Miercoles')); ?>:</b>
	<?php echo CHtml::encode($data->Numero_Mensajeros_Miercoles); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Jueves_Servicios')); ?>:</b>
	<?php echo CHtml::encode($data->Jueves_Servicios); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Numero_Mensajeros_Jueves')); ?>:</b>
	<?php echo CHtml::encode($data->Numero_Mensajeros_Jueves); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Viernes_Servicios')); ?>:</b>
	<?php echo CHtml::encode($data->Viernes_Servicios); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Numero_Mensajeros_Viernes')); ?>:</b>
	<?php echo CHtml::encode($data->Numero_Mensajeros_Viernes); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Sabado_Servicios')); ?>:</b>
	<?php echo CHtml::encode($data->Sabado_Servicios); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Numero_Mensajeros_Sabado')); ?>:</b>
	<?php echo CHtml::encode($data->Numero_Mensajeros_Sabado); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Domingo_Servicios')); ?>:</b>
	<?php echo CHtml::encode($data->Domingo_Servicios); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Numero_Mensajeros_Domingo')); ?>:</b>
	<?php echo CHtml::encode($data->Numero_Mensajeros_Domingo); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ClienteFiel_Servicios')); ?>:</b>
	<?php echo CHtml::encode($data->ClienteFiel_Servicios); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Numero_Mensajeros_ClienteFiel')); ?>:</b>
	<?php echo CHtml::encode($data->Numero_Mensajeros_ClienteFiel); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Promedio_Mensajeros_Hora_Normal')); ?>:</b>
	<?php echo CHtml::encode($data->Promedio_Mensajeros_Hora_Normal); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Promedio_Mensajeros_Hora_Festivo')); ?>:</b>
	<?php echo CHtml::encode($data->Promedio_Mensajeros_Hora_Festivo); ?>
	<br />

	*/ ?>

</div>