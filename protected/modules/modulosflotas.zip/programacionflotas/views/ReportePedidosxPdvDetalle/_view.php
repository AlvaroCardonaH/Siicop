<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdReportePedidosxPdvDetalle')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->IdReportePedidosxPdvDetalle),array('view','id'=>$data->IdReportePedidosxPdvDetalle)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdReportePedidosxPdv')); ?>:</b>
	<?php echo CHtml::encode($data->IdReportePedidosxPdv); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NumeroDeRegistro')); ?>:</b>
	<?php echo CHtml::encode($data->NumeroDeRegistro); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CodigoPdv')); ?>:</b>
	<?php echo CHtml::encode($data->CodigoPdv); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NombrePdv')); ?>:</b>
	<?php echo CHtml::encode($data->NombrePdv); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Caja')); ?>:</b>
	<?php echo CHtml::encode($data->Caja); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Factura')); ?>:</b>
	<?php echo CHtml::encode($data->Factura); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('Valor')); ?>:</b>
	<?php echo CHtml::encode($data->Valor); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NombreMensajero')); ?>:</b>
	<?php echo CHtml::encode($data->NombreMensajero); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CelularMensajero')); ?>:</b>
	<?php echo CHtml::encode($data->CelularMensajero); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NombreCliente')); ?>:</b>
	<?php echo CHtml::encode($data->NombreCliente); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('DireccionCliente')); ?>:</b>
	<?php echo CHtml::encode($data->DireccionCliente); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TelefonoCliente')); ?>:</b>
	<?php echo CHtml::encode($data->TelefonoCliente); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('EstadoPedido')); ?>:</b>
	<?php echo CHtml::encode($data->EstadoPedido); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CausalEntrega')); ?>:</b>
	<?php echo CHtml::encode($data->CausalEntrega); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FechaPos')); ?>:</b>
	<?php echo CHtml::encode($data->FechaPos); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FechaAceptacion')); ?>:</b>
	<?php echo CHtml::encode($data->FechaAceptacion); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TiempoEspera')); ?>:</b>
	<?php echo CHtml::encode($data->TiempoEspera); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FechaEntrega')); ?>:</b>
	<?php echo CHtml::encode($data->FechaEntrega); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TiempoTotalMinutos')); ?>:</b>
	<?php echo CHtml::encode($data->TiempoTotalMinutos); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdRuta')); ?>:</b>
	<?php echo CHtml::encode($data->IdRuta); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CodigoEstadoRegistro')); ?>:</b>
	<?php echo CHtml::encode($data->CodigoEstadoRegistro); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('EsDiaFestivo')); ?>:</b>
	<?php echo CHtml::encode($data->EsDiaFestivo); ?>
	<br />

	*/ ?>

</div>